import csv

import matplotlib.pyplot as plt
import numpy as np

dic = {}

start_line = 8
end_line = 295
max_entries = 5
highest = False

with open('./exec.csv') as csv_file:
    csv_reader = csv.reader(csv_file, delimiter=';')
    line_count = 0

    for row in csv_reader:

        if line_count <= start_line: line_count+=1; continue
        if line_count >= end_line: break


        try:
            country = row[0]
            year = row[1]
            val = float( row[3].replace(",", ".") )

            if year != '2019': continue

            print('%s - %f' % (country, val))


            dic[country] = val
            line_count += 1

        except:
            continue

print(dic)

labels = []
values = []

arr = []

for key in dic:
    arr.append([key, dic[key]])


arr2 = []
oecd_added = False

for ii in range(max_entries):

    current_country = ''
    current_value = ''
    current_index = -1

    for i in range(len(arr)):
        if arr[i][0] == 'OECD-Durchschnitt 4)' and not oecd_added: arr2.append([arr[i][0], arr[i][1]]); oecd_added = True ;continue
        if i == 0: current_country = arr[i][0]; current_value = arr[i][1]; current_index = i
        if arr[i][1] >= current_value if highest else arr[i][1] <= current_value :  current_country = arr[i][0]; current_value = arr[i][1]; current_index = i


    arr2.append([current_country, current_value])
    del(arr[current_index])


for val in arr2:
    labels.append(val[0])
    values.append(val[1])

x = np.array(labels)
y = np.array(values)

plt.bar(x, y,)

for index, value in enumerate(y):
    plt.text(index, value, str(value))

plt.show()

input("close?")
